from django.contrib import admin
from .models import EntryTest
# Register your models here.
admin.site.register(EntryTest)